# Chef RPG — Tradução PT-BR

Este pacote traduz os textos de Chef RPG para português do Brasil. Ele altera apenas
um arquivo de dados do jogo: `Chef RPG_Data/resources.assets`.

## Instalação

1. Feche o Chef RPG e a Steam.
2. Abra a pasta de instalação do jogo pela Steam: **Biblioteca > Chef RPG >
   Gerenciar > Procurar arquivos locais**.
3. Copie a pasta `Chef RPG_Data` deste pacote para a pasta raiz de Chef RPG.
4. Confirme a substituição de `resources.assets` quando o Windows perguntar.
5. Abra o jogo normalmente pela Steam.

## Requisitos

Não é necessário instalar UABEA, BepInEx, Python, .NET ou qualquer outro programa.

## O que está incluído

As cinco tabelas de localização dentro de `resources.assets`:

- diálogos e missões;
- interface e menus;
- romances;
- festivais;
- itens.

Os arquivos de cena `level*` não fazem parte deste lançamento.

## Como desfazer

Use **Propriedades > Arquivos instalados > Verificar integridade dos arquivos do
jogo** na Steam. Ela restaura o arquivo original.

## Compatibilidade

Este pacote foi gerado a partir da instalação validada em 07/09/2026. Se Chef RPG
receber uma atualização, faça a verificação de integridade e aguarde uma versão nova
da tradução antes de reportar erro.
