# Changelog

## 2026-09-07

- Tradução PT-BR das cinco tabelas de texto em `resources.assets`.
- 25.768 registros validados após a reconstrução.
- Pacote limitado a `resources.assets`; cenas de UI `level*` não incluídas.
